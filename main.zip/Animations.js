/**
 * Created by Spikey on 16.05.2015.
 */
function openCard(a, b){
    console.log("click");

}
function nextMove(a, b, hero) {

}